

<footer id="footer">
  Pied de page
</footer>
 <?php
  wp_footer();
 ?>
</body>
</html>
